
	// Edit Submit Action
	var progressbar     = $('#form-edit-categories .progress-bar');
	$(".edit-submit").click(function(){
		$(".edit-submit").prop("disabled", true).css("cursor", 'not-allowed');
		$("#form-edit-categories .loading-button").css("display", 'inline-block');
			$("#form-edit-categories").ajaxForm(
				{
					target: '#form-edit-categories .preview',
					beforeSend: function() {
						$("#form-edit-categories .progress").css("display","block");
						progressbar.width('0%');
						progressbar.text('0%');
		},
				uploadProgress: function (event, position, total, percentComplete) {
				progressbar.width(percentComplete + '%');
				progressbar.text(percentComplete + '%');
				},
				success: function(data) {
					if(data.status == 'success'){
						$('#form-edit-categories .mess').removeClass('alert alert-danger');
						$('#form-edit-categories .mess').addClass('alert alert-success');
						$('#form-edit-categories .mess').html(data.message);
						$(".edit-submit").prop("disabled", false).css("cursor", 'pointer');
						$("#form-edit-categories .loading-button").css("display", 'none');
					}else{
						var errorString = '';
						$.each( data.message, function( key, value) {
							errorString += '<li>' + value + '</li>';
						});
						$('#form-edit-categories .mess').removeClass('alert alert-success');
						$('#form-edit-categories .mess').addClass('alert alert-danger');
						$('#form-edit-categories .mess').html(errorString);
						$(".edit-submit").prop("disabled", false).css("cursor", 'pointer');
						$("#form-edit-categories .loading-button").css("display", 'none');
					}
					$('div').animate({ scrollTop: $('.progress').offset().top }, 'slow');
				}
				})
			.submit();
	});