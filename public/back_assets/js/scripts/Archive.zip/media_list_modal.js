
$("#choose-image-radio  input[name='media_id[]']:radio").on("change", function() {
	var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');
    var base_url = window.location.origin;
	var media_id = $(this).val();
	$.ajax({
		type:"GET",
		url: base_url+"/backadmin/choose-media/"+media_id,
		data: {
		_token: CSRF_TOKEN,
	},
	success: function(data){
		if($('#modal-add-slider').is(':visible')){
			$('#image_output').html('');
			$('#media_id').val(data.id);
			$('#image_output').html('<img style="max-width:250px; margin:10px auto;" src="../media/originals/'+data.filename+'" alt="'+data.name+'">');
			$('#modal-choose-media').modal('hide');
		}else if($('#modal-edit-home-slider').is(':visible')){
			$('#edit-image_output').html('');
			$('#edit-media_id').val(data.id);
			$('#edit-image_output').html('<img style="max-width:250px; margin:10px auto;" src="../media/originals/'+data.filename+'" alt="'+data.name+'">');
			$('#modal-choose-media').modal('hide');
		}
		else if($('#modal-add-event').is(':visible')){
			$('#modal-add-event #image_output').html('');
			$('#modal-add-event #media_id').val(data.id);
			$('#modal-add-event #event-type').val(data.type);
			$('#modal-add-event #image_output').html('<img style="max-width:250px; margin:10px auto;" src="../../media/originals/'+data.filename+'" alt="'+data.name+'">');
			$('#modal-choose-media').modal('hide');
		}
		else if($('#modal-edit-event').is(':visible')){
			$('#modal-edit-event #image_output').html('');
			$('#modal-edit-event #media_id').val(data.id);
			$('#modal-edit-event #event-type').val(data.type);
			$('#modal-edit-event #image_output').html('<img style="max-width:250px; margin:10px auto;" src="../../media/originals/'+data.filename+'" alt="'+data.name+'">');
			$('#modal-choose-media').modal('hide');
		}else if($('#modal-add-case').is(':visible')){
			$('#modal-add-case #image_output').html('');
			$('#modal-add-case #media_id').val(data.id);
			$('#modal-add-case #case-type').val(data.type);
			$('#modal-add-case #image_output').html('<img style="max-width:250px; margin:10px auto;" src="../../media/originals/'+data.filename+'" alt="'+data.name+'">');
			$('#modal-choose-media').modal('hide');
		}else if($('#modal-edit-case').is(':visible')){
			$('#modal-edit-case #image_output').html('');
			$('#modal-edit-case #media_id').val(data.id);
			$('#modal-edit-case #case-type').val(data.type);
			$('#modal-edit-case #image_output').html('<img style="max-width:250px; margin:10px auto;" src="../../media/originals/'+data.filename+'" alt="'+data.name+'">');
			$('#modal-choose-media').modal('hide');
		}
	}
	});
	return false;
});